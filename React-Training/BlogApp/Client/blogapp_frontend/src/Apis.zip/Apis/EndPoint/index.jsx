import { BlogEndPoints } from "./Blog";

export default{BlogEndPoints}