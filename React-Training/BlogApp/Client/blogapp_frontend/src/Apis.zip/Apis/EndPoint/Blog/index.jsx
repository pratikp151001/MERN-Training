export const BlogEndPoints = {
    INSERT_BLOG: '/addblog',
    FETCHALL_BLOG:'/fetchblog',
    DELETE:(id)=>`/deleteblog/${id}`,
    FETCHSINGLE_BLOG:(id)=>`/fetchblog/${id}`
   
  };
  