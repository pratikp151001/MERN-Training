import { ResponseStatus } from "../InterfaceandTypes";

export class CommanResponse {
   ResponseStatus
   Result
   Message
   Status
}
