export class requestModel {
     url
     method
     params
     data
     headers
     timeout
     withCredentials
     responseType
     responseEncoding
     xsrfCookieName
     xsrfHeaderName
     maxContentLength
     maxBodyLength
    
  }
  