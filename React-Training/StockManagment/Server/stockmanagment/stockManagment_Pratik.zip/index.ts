import Server from "./Server";
const app= new Server();
app.start()