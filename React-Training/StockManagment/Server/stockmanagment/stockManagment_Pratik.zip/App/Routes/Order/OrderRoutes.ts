import  express  from "express";
import Controller from "../../Controller/index";
// import VerifyToken from "../../Middleware/TokenVerify";

const router=express.Router()

router.post('/addorder',Controller.AddOrder.AddOrder)





export  default router;