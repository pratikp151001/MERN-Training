export interface responseModel {
    customername:string,
    quantityordered:number,
    stocksname:String
}