export interface AddStockModel {
    stockname:string,
    quantity:number

}