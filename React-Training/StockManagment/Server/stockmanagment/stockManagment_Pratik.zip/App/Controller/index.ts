import AddStock from "./Stock/AddStock";
import GetStock from "./Stock/GetStock"
import DeleteStock from "./Stock/DeleteStock"
import AddOrder from "./Order/AddOrder"

export default {
    AddStock,GetStock,DeleteStock,AddOrder
}