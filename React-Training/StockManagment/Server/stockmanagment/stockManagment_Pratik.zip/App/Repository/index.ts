import StockRepositoty from "../Repository/StockRepo/StockRepo"

export default {StockRepositoty}
