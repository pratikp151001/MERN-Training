import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import GetStockAction from '../../Redux/Actions/GetAllStocks';
import "../Order/Order.css"
import AddOrder from '../../Redux/Actions/AddOrder';

export default function Order() {

    const dispatch = useDispatch()
    const STOCKS = useSelector((state) => state.stock)
    console.log("🚀 ~ file: Order.jsx:10 ~ Order ~ STOCKS:", STOCKS)

    const [value, setValue] = useState({})

    useEffect(() => {
        dispatch(GetStockAction())
    }, [])

    const getformvalue = (e) => {
        const { name, value } = e.target
        console.log("🚀 ~ file: Order.jsx:18 ~ getformvalue ~ value:", value)
        console.log("🚀 ~ file: Order.jsx:18 ~ getformvalue ~ name:", name)
        setValue({ ...value, [name]: value })
    }

    const oderStocks = (e) => {
        if (Object.keys(value).length == 3) {
            dispatch(AddOrder(value))
        }
        else {
            alert("Enter all Details")
        }

    }
    return (
        <div>
            <div className='mainbody'>

                <div class="row">
                    <div class="col">
                        <h2>Order</h2>
                    </div>
                    <div class="col">

                    </div>
                    <div class="col text-end me-5">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                            Add Order
                        </button>
                    </div>
                </div>

                {/* <!-- Modal --> */}
                <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="exampleModalLabel">Add Order</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="mb-3">
                                    <label for="customername" class="form-label">Customer Name</label>
                                    <input type="text" name='customername' onChange={(e) => { getformvalue(e) }} class="form-control" id="customername" />
                                </div>
                                <div class="mb-3">
                                    <label for="quantityorder" class="form-label">Quantity</label>
                                    <input type="number" min={1} name='quantityorder' onChange={(e) => { getformvalue(e) }} class="form-control" id="quantityorder" />
                                </div>
                                <select onChange={(e) => { getformvalue(e) }} name='stockname' class="form-select" aria-label="Default select example">
                                    <option selected>Open this select menu</option>
                                    {STOCKS?.all_stock?.map((index, stock) => {
                                        return <option value={stock.stockname}>{stock.stockname}</option>
                                    })}

                                </select>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" onClick={(e) => { oderStocks(e) }} class="btn btn-primary">Order</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}
