import { StockActiontype } from "../Action-type";

const initianState = {
    error: null,
    isLoading: false,
    added_stock: null,
    all_stock: null,
    deleted_stock:null
}

const OrderReducer = (state = initianState, actions) => {
    switch (actions.type) {
        case (StockActiontype.ADD_STOCK_REQUEST):
            return {
                ...state, isLoading: true
            }
        case (StockActiontype.ADD_STOCK_SUCCESS):
            console.log("object", "d")
            return {
                ...state, isLoading: false, added_stock: actions.payload
            }
        case (StockActiontype.ADD_STOCK_FAIL):
            return {
                ...state, isLoading: false, error: actions.error
            }
            default:
                return state
        }
    }

    export default OrderReducer